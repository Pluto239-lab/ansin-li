package com.example.demo.mapper;

import com.example.demo.entity.Beework;



import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;




@Mapper
public interface BeeworkMapper {
    @Select("SELECT AUTHORITY, COMPANY_ID, PHOTO_ADDRESS, SEX, UPDATE_TIME, USER_CD, USER_MAIL, FIRST_NAME, LAST_NAME, USER_STATUS, USER_TEL FROM user_tbl WHERE 	DEL_FLG	= '0' AND \r\n"
    		+ "	(\r\n"
    		+ "	AUTHORITY IN '21'、'31'\r\n"
    		+ "	OR(\r\n"
    		+ "	AUTHORITY = '11'\r\n"
    		+ "	AND\r\n"
    		+ "	a0301VueForm.authority = '00'\r\n"
    		+ "	)\r\n"
    		+ "	)AND\r\n"
    		+ "	LAST_NAME || FIRST_NAME	LIKE ' %A0301VueForm.userName%' AND	\r\n"
    		+ "	USER_MAIL	LIKE	 '%A0301VueForm.userMail%'	AND	\r\n"
    		+ "	USER_TEL LIKE '%A0301VueForm.userTel%' ORDER BY UPDATE_TIME,desc")
    Beework getBeeworkById(@Param("USER_CD") Long userCd);

}
