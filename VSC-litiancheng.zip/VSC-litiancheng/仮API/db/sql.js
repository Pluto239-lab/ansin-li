const db = require('../db');

const userService = {
    // 获取所有用户
    getAdminUserList: async ({ authority, userName, userMail, userTel }) => {
        // 基本 SELECT 字段
        const baseColumns = `
    USER_TBL.USER_CD,
    USER_TBL.PWD,
    USER_TBL.COMPANY_ID,
    USER_TBL.AUTHORITY,
    USER_TBL.FIRST_NAME_KANA,
    USER_TBL.FIRST_NAME,
    USER_TBL.LAST_NAME_KANA,
    USER_TBL.LAST_NAME,
    USER_TBL.SEX,
    USER_TBL.COUNTRY_ZIP,
    USER_TBL.USER_TEL,
    USER_TBL.USER_MAIL,
    USER_TBL.PHOTO_ADDRESS,
    USER_TBL.USER_STATUS,
    USER_TBL.DEL_FLG,
    USER_TBL.CREATE_TIME,
    USER_TBL.CREATE_BY,
    USER_TBL.UPDATE_TIME,
    USER_TBL.UPDATE_BY
  `;

        // 动态拼接 SQL 语句
        let sql = `SELECT ${baseColumns} FROM USER_TBL WHERE DEL_FLG = '0'`;
        const params = [];

        // 权限筛选（'00' 管理员 -> 包含'11','31','21'，否则只'31','21'）
        if (authority === '00') {
            sql += ` AND USER_TBL.AUTHORITY IN ('11','31','21')`;
        } else {
            sql += ` AND USER_TBL.AUTHORITY IN ('31','21')`;
        }

        // 条件拼接
        if (userName) {
            sql += ` AND CONCAT(IFNULL(USER_TBL.LAST_NAME, ''), IFNULL(USER_TBL.FIRST_NAME, '')) LIKE ?`;
            params.push(`%${userName}%`);
        }

        if (userMail) {
            sql += ` AND USER_TBL.USER_MAIL LIKE ?`;
            params.push(`%${userMail}%`);
        }

        if (userTel) {
            sql += ` AND USER_TBL.USER_TEL LIKE ?`;
            params.push(`%${userTel}%`);
        }

        // 排序
        sql += ` ORDER BY USER_TBL.UPDATE_TIME DESC`;

        // 执行查询
        return await db.query(sql, params);
    },


    // 根据 ID 查询用户
    getUserById: async (id) => {
        return await db.query('SELECT * FROM users WHERE id = ?', [id]);
    },

    // 创建新用户
    createUser: async (name, age) => {
        return await db.query('INSERT INTO users (name, age) VALUES (?, ?)', [name, age]);
    },

    // 更新用户
    updateUser: async (id, name, age) => {
        return await db.query('UPDATE users SET name = ?, age = ? WHERE id = ?', [name, age, id]);
    },

    // 删除用户
    deleteUser: async (id) => {
        return await db.query('DELETE FROM users WHERE id = ?', [id]);
    }
};

module.exports = userService;